// src/cardEnhancer.js
// Card detection and enhancement logic (to be TDD'd)

function findMovieCards(doc) {
  doc = doc || document;
  const cards = Array.from(doc.querySelectorAll('.card[data-type="Movie"]'));
  console.log('[Jellyfin Extension] Found', cards.length, 'movie cards');
  
  // Also try alternative selectors in case the structure is different
  if (cards.length === 0) {
    const alternativeCards = Array.from(doc.querySelectorAll('.card'));
    console.log('[Jellyfin Extension] Found', alternativeCards.length, 'total cards');
    
    // Log first few cards to see their structure
    alternativeCards.slice(0, 3).forEach((card, i) => {
      console.log(`[Jellyfin Extension] Card ${i}:`, {
        classes: card.className,
        dataType: card.getAttribute('data-type'),
        dataId: card.getAttribute('data-id'),
        innerHTML: card.innerHTML.substring(0, 200) + '...'
      });
    });
  }
  
  return cards;
// End of triggerNativeDeleteProcess

// Human readable file size (binary units, 1KB = 1024B) with single decimal except bytes.
function formatFileSize(bytes) {
  if (bytes === null || bytes === undefined || isNaN(bytes)) return '';
  if (!isFinite(bytes) || bytes < 0) return '';
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const k = 1024;
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  if (i === 0) return bytes + ' B';
  const value = bytes / Math.pow(k, i);
  return value.toFixed(1) + ' ' + units[i];
}

// Build attribute list respecting option flags.
function buildAttributesList(item, options) {
  if (!item || !options) return [];
  const attrs = [];
  const mediaSource = item.MediaSources && item.MediaSources[0];

  if (options.showFileSize && mediaSource && typeof mediaSource.Size === 'number') {
    const sizeStr = formatFileSize(mediaSource.Size);
    if (sizeStr) attrs.push(sizeStr);
  }

  if (options.showFileName && item.Path) {
    const parts = item.Path.split(/[/\\]/);
    const name = parts[parts.length - 1];
    if (name) attrs.push(name);
  }

  if (options.showContainer && mediaSource && mediaSource.Container) {
    attrs.push(String(mediaSource.Container).toUpperCase());
  }

  if (options.showResolution && mediaSource && Array.isArray(mediaSource.MediaStreams)) {
    const vs = mediaSource.MediaStreams.find(s => s && s.Type === 'Video' && s.Width && s.Height);
    if (vs) attrs.push(`${vs.Width}×${vs.Height}`);
  }

  if (options.showHDR && mediaSource && Array.isArray(mediaSource.MediaStreams)) {
    const vs = mediaSource.MediaStreams.find(s => s && s.Type === 'Video');
    if (vs) {
      // Check for HDR indicators in various fields
      const isHDR = vs.VideoRange === 'HDR' || 
                    vs.ColorTransfer === 'smpte2084' || 
                    vs.ColorTransfer === 'arib-std-b67' ||
                    (vs.Profile && vs.Profile.toLowerCase().includes('hdr')) ||
                    (vs.VideoRangeType && vs.VideoRangeType !== 'SDR');
      
      if (isHDR) {
        // Try to determine HDR type
        if (vs.ColorTransfer === 'smpte2084') {
          try {
            console.log('[Jellyfin Extension] triggerNativeDeleteProcess called for itemId:', itemId);
            const cardElement = document.querySelector(`[data-id="${itemId}"]`);
            if (!cardElement) {
              console.warn('[Jellyfin Extension] Card element not found for itemId:', itemId);
              return false;
            }
            console.log('[Jellyfin Extension] Found card element:', cardElement);
            const moreButtonSelectors = [
              '.btnCardMoreOptions',
              '.cardMoreButton', 
              '.btnCardMore',
              '.card-more-button',
              '[data-action="menu"]',
              '.material-icons[title="More"]',
              '.md-icon-button[title="More"]',
              'button[title="More"]',
              '.more-vert',
              '.mdi-dots-vertical'
            ];
            let moreButton = null;
            for (const selector of moreButtonSelectors) {
              moreButton = cardElement.querySelector(selector);
              if (moreButton) {
                console.log('[Jellyfin Extension] Found more button with selector:', selector, moreButton);
                moreButton.click();
                break;
              }
            }
            if (!moreButton) {
              console.warn('[Jellyfin Extension] Could not find more button for card:', cardElement);
              return false;
            }
            setTimeout(() => {
              const menu = document.querySelector('.menu, .md-menu, .dropdown-menu');
              if (menu) {
                const deleteOption = Array.from(menu.querySelectorAll('button, .menuItem, .md-menu-item')).find(el => el.textContent.match(/delete/i));
                if (deleteOption) {
                  console.log('[Jellyfin Extension] Found delete option in menu:', deleteOption);
                  const deleteClickEvent = new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    view: window
                  });
                  deleteOption.dispatchEvent(deleteClickEvent);
                  console.log('[Jellyfin Extension] Clicked delete option');
                } else {
                  console.warn('[Jellyfin Extension] Could not find delete option in menu:', menu);
                }
              } else {
                console.warn('[Jellyfin Extension] Could not find menu after clicking more button');
              }
            }, 500);
            return true;
          } catch (error) {
            console.error('[Jellyfin Extension] Error in triggerNativeDeleteProcess:', error);
            return false;
          }
  let others = [];
  const hdrKeywords = ['SDR', 'HDR', 'HDR10', 'HLG', 'Dolby Vision'];
  const resolutionRegex = /^\d{3,5}×\d{3,5}$/;
  const sizeRegex = /^\d+\.\d+\s*(MB|GB|KB)$/i;
  const containerRegex = /^(MP4|MKV|AVI|MOV|FLV|WMV|WebM)$/i;
  const langRegex = /^(English|Japanese|Chinese|French|German|Spanish|Italian|Russian|Portuguese|Hindi|Arabic)$/i;

  if (attributes.length > 0) {
    for (let i = 0; i < attributes.length; i++) {
      const attr = attributes[i];
      if (attr.includes('.') && !attr.includes(' ')) {
        filename = attr;
      } else if (sizeRegex.test(attr)) {
        size = attr;
      } else if (containerRegex.test(attr)) {
        container = attr;
      } else if (langRegex.test(attr)) {
        audioLang = attr;
      } else if (resolutionRegex.test(attr)) {
        resolution = attr;
      } else if (hdrKeywords.some(k => attr === k)) {
        hdr = attr;
      } else {
        others.push(attr);
      }
    }
  }

  // Set attributes on card
  if (filename) {
    cardEl.setAttribute('data-filename', filename);
    const filenameDiv = document.createElement('div');
    filenameDiv.className = 'cardText-secondary movie-attributes movie-attributes-filename';
    filenameDiv.textContent = filename;
    cardText.appendChild(filenameDiv);
    console.log('[Jellyfin Extension] Set data-filename on card:', cardEl.getAttribute('data-id'), filename);
  }
  if (size) {
    cardEl.setAttribute('data-size', size);
  }
  if (container) {
    cardEl.setAttribute('data-container', container);
  }
  if (audioLang) {
    cardEl.setAttribute('data-audio-lang', audioLang);
  }
  if (resolution) {
    cardEl.setAttribute('data-resolution', resolution);
  }
  if (hdr) {
    cardEl.setAttribute('data-hdr', hdr);
  }
  // Create other attributes line
  if (others.length > 0) {
    const attrsDiv = document.createElement('div');
    attrsDiv.className = 'cardText-secondary movie-attributes movie-attributes-details';
    attrsDiv.textContent = others.join(' • ');
    cardText.appendChild(attrsDiv);
  }
  // Create resolution/HDR line
  if (resolution || hdr) {
    const resDiv = document.createElement('div');
    resDiv.className = 'cardText-secondary movie-attributes movie-attributes-res';
    let resText = '';
    if (resolution) resText += resolution;
    if (hdr) resText += (resText ? ' • ' : '') + hdr;
    resDiv.textContent = resText;
    cardText.appendChild(resDiv);
  }
  return true;
}

// Add action buttons to a card element
function addActionButtonsToCard(cardEl, itemId, options = {}) {
  if (!cardEl || !itemId) return false;
  const cardText = cardEl.querySelector('.cardText');
  if (!cardText) return false;
  if (cardText.querySelector('.movie-action-buttons')) return false; // prevent duplication

  // Check if any buttons should be shown
  const showDeleteButton = options.showDeleteButton || false;
  const showIdentifyButton = options.showIdentifyButton || false;
  
  if (!showDeleteButton && !showIdentifyButton) return false;

  // Create button container
  const buttonContainer = document.createElement('div');
  buttonContainer.className = 'movie-action-buttons';
  
  // Create Delete Media button
  if (showDeleteButton) {
    const deleteButton = document.createElement('button');
    deleteButton.className = 'jellyfin-action-btn jellyfin-delete-btn';
    deleteButton.textContent = 'Delete';
    deleteButton.setAttribute('data-item-id', itemId);
    deleteButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      console.log('[Jellyfin Extension] Delete button clicked for item:', itemId);
      
      // Debug mode - hold Ctrl while clicking to inspect card structure
      if (e.ctrlKey) {
        debugCardStructure(itemId);
        return;
      }
      
      triggerDeleteDialog(itemId);
    });
    // Prevent any parent click handlers
    deleteButton.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    });
    buttonContainer.appendChild(deleteButton);
  }

  // Create Identify button
  if (showIdentifyButton) {
    const identifyButton = document.createElement('button');
    identifyButton.className = 'jellyfin-action-btn jellyfin-identify-btn';
    identifyButton.textContent = 'Identify';
    identifyButton.setAttribute('data-item-id', itemId);
    identifyButton.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      console.log('[Jellyfin Extension] Identify button clicked for item:', itemId);
      
      // Debug mode - hold Ctrl while clicking to inspect card structure
      if (e.ctrlKey) {
        debugCardStructure(itemId);
        return;
      }
      
      triggerIdentifyDialog(itemId);
    });
    // Prevent any parent click handlers
    identifyButton.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    });
    buttonContainer.appendChild(identifyButton);
  }

  cardText.appendChild(buttonContainer);
  return true;
}

// Trigger Jellyfin's native delete dialog
function triggerDeleteDialog(itemId) {
  console.log('[Jellyfin Extension] Triggering delete dialog for item:', itemId);
  
  // Get item details first
  getItemDetailsForDialog(itemId).then(itemInfo => {
    console.log('[Jellyfin Extension] Got item info:', itemInfo);
    
    // Retrieve all extra attributes from card
    const cardElement = document.querySelector(`[data-id="${itemId}"]`);
    let deleteMessage = `Delete Item\n\n`;
    if (cardElement) {
      const attrList = [
        ['Filename', 'data-filename'],
        ['Size', 'data-size'],
        ['Container', 'data-container'],
        ['Audio Language', 'data-audio-lang'],
        ['Resolution', 'data-resolution'],
        ['SDR/HDR', 'data-hdr']
      ];
      for (const [label, attr] of attrList) {
        if (cardElement.hasAttribute(attr)) {
          deleteMessage += `${label}: ${cardElement.getAttribute(attr)}\n`;
        }
      }
    } else {
      deleteMessage += `Attributes not available\n`;
    }
    deleteMessage += `\nDeleting this item will delete it from both the file system and your media library. Are you sure you wish to continue?`;
    
    const userConfirmed = confirm(deleteMessage);
    
    if (userConfirmed) {
      console.log('[Jellyfin Extension] User confirmed deletion, executing delete');
      executeDelete(itemId);
    } else {
      console.log('[Jellyfin Extension] User cancelled deletion');
    }
      
  }).catch(error => {
    console.error('[Jellyfin Extension] Failed to get item details:', error);
    // Show dialog with basic info even if API fails
    const fallbackMessage = `Delete Item\n\nTitle: Unknown Title\nFilename: Unable to retrieve filename\nPath: Unable to retrieve path\n\nDeleting this item will delete it from both the file system and your media library. Are you sure you wish to continue?`;
    
    const userConfirmed = confirm(fallbackMessage);
    if (userConfirmed) {
      executeDelete(itemId);
    }
  });
}

// Function to execute the actual delete operation
function executeDelete(itemId) {
  console.log('[Jellyfin Extension] Executing delete for item:', itemId);
  if (!itemId) {
    console.error('[Jellyfin Extension] No itemId provided to executeDelete');
    fallbackDelete(itemId);
    return;
  }
  try {
    // Method 1: Try direct API delete if we have access
    if (window.ApiClient) {
      console.log('[Jellyfin Extension] Using ApiClient for delete, itemId:', itemId);
      window.ApiClient.deleteItem(itemId).then(() => {
        console.log('[Jellyfin Extension] Delete successful via ApiClient');
        window.location.reload();
      }).catch(error => {
        console.error('[Jellyfin Extension] ApiClient delete failed:', error);
        fallbackDelete(itemId);
      });
      return;
    }
    // Method 2: Try to trigger native delete without dialog
    console.log('[Jellyfin Extension] Attempting native delete for itemId:', itemId);
    if (!triggerNativeDeleteWithoutDialog(itemId)) {
      console.log('[Jellyfin Extension] Native delete fallback failed for itemId:', itemId);
      fallbackDelete(itemId);
    }
  } catch (error) {
    console.error('[Jellyfin Extension] Error executing delete:', error);
    fallbackDelete(itemId);
  }
}

// Function to trigger native delete without showing dialog
function triggerNativeDeleteWithoutDialog(itemId) {
  try {
    // Override confirm to automatically return true for delete operations
    const originalConfirm = window.confirm;
    let confirmed = false;
    
    window.confirm = function(message) {
      console.log('[Jellyfin Extension] Auto-confirming delete message:', message);
      // Restore original immediately
      window.confirm = originalConfirm;
      confirmed = true;
      return true;
    };
    
    // Set timeout to restore confirm function as safety
    setTimeout(() => {
      window.confirm = originalConfirm;
    }, 1000);
    
    const result = triggerNativeDeleteProcess(itemId);
    return result && confirmed;
  } catch (error) {
    console.error('[Jellyfin Extension] Error in triggerNativeDeleteWithoutDialog:', error);
    return false;
  }
}

// Fallback delete function
function fallbackDelete(itemId) {
  console.log('[Jellyfin Extension] Fallback delete for:', itemId);
  alert('Unable to delete item automatically. Please use Jellyfin\'s native delete option from the more menu (⋮).');
}

// Separate function to handle the native delete process triggering
function triggerNativeDeleteProcess(itemId) {
  try {
    // Method 1: Look for the card's more button and simulate click
    const cardElement = document.querySelector(`[data-id="${itemId}"]`);
    if (cardElement) {
      console.log('[Jellyfin Extension] Found card element:', cardElement);
      
      // Try different selectors for the more button
      const moreButtonSelectors = [
        '.btnCardMoreOptions',
        '.cardMoreButton', 
        '.btnCardMore',
        '.card-more-button',
        '[data-action="menu"]',
        '.material-icons[title="More"]',
        '.md-icon-button[title="More"]',
        'button[title="More"]',
        '.more-vert',
// (All code above replaced by the refactored function)
}

// Get item details for showing in dialog
async function getItemDetailsForDialog(itemId) {
  console.log('[Jellyfin Extension] Getting item details for:', itemId);
  
  try {
    // Try multiple methods to get the item details
  // item will be assigned below
    
    // Method 1: Use the extension's API client if available
    // Try extension API client first
    let item = null;
    if (window.JellyfinExtension && window.JellyfinExtension.apiClient) {
      console.log('[Jellyfin Extension] Trying extension API client');
      const { fetchItemDetails } = window.JellyfinExtension.apiClient;
      const baseUrl = extractBaseUrl();
      const token = extractAccessToken();
      if (baseUrl && token) {
        console.log('[Jellyfin Extension] Using baseUrl:', baseUrl, 'token available:', !!token);
        item = await fetchItemDetails(itemId, {
          baseUrl,
          token,
          fields: [
            'Path', 'MediaSources', 'Name', 'FileName', 'Container', 'OriginalTitle', 'Size', 'Type', 'Overview', 'PremiereDate', 'ProductionYear', 'IsFolder'
          ]
        });
        console.log('[Jellyfin Extension] Got item from extension API:', item);
      }
    }
    // If extension API fails, try native API client
    if ((!item || (!item.Path && (!Array.isArray(item.MediaSources) || item.MediaSources.length === 0))) && window.ApiClient) {
      console.log('[Jellyfin Extension] Trying native ApiClient');
      try {
        item = await window.ApiClient.getItem(window.ApiClient.getCurrentUserId(), itemId);
        console.log('[Jellyfin Extension] Got item from native API:', item);
      } catch (apiError) {
        console.log('[Jellyfin Extension] Native API failed:', apiError);
      }
    }
    // Only fall back to card content if API result is truly missing or invalid
    if (!item || (!item.Path && (!Array.isArray(item.MediaSources) || item.MediaSources.length === 0))) {
      console.log('[Jellyfin Extension] API result missing key fields, falling back to card content');
      const cardElement = document.querySelector(`[data-id="${itemId}"]`);
      if (cardElement) {
        const titleElement = cardElement.querySelector('.cardText-first, .cardTitle, .itemName, h3, .primary');
        const title = titleElement ? titleElement.textContent.trim() : 'Unknown Title';
        item = {
          Name: title,
          Path: null,
          MediaSources: null
        };
        console.log('[Jellyfin Extension] Extracted title from card:', item);
      }
    }
    
    if (!item) {
      throw new Error('Could not retrieve item details from any source');
    }
    
    // Extract the information we need from the API data
    let filename = 'Unknown file';
    let path = 'Unknown path';
    let mediaSource = Array.isArray(item.MediaSources) ? item.MediaSources[0] : null;
    
    // Prefer item.Path, then mediaSource.Path
    if (item.Path && typeof item.Path === 'string') {
      path = item.Path;
      const parts = item.Path.split(/[/\\]/);
      filename = parts[parts.length - 1] || 'Unknown file';
      console.log('[Jellyfin Extension] Using item.Path:', path);
      console.log('[Jellyfin Extension] Extracted filename from item.Path:', filename);
    } else if (mediaSource && mediaSource.Path && typeof mediaSource.Path === 'string') {
      path = mediaSource.Path;
      const parts = mediaSource.Path.split(/[/\\]/);
      filename = parts[parts.length - 1] || 'Unknown file';
      console.log('[Jellyfin Extension] Using mediaSource.Path:', path);
      console.log('[Jellyfin Extension] Extracted filename from mediaSource.Path:', filename);
    } else if (mediaSource && mediaSource.Name && typeof mediaSource.Name === 'string') {
      filename = mediaSource.Name;
      console.log('[Jellyfin Extension] Using mediaSource.Name:', filename);
    } else {
      path = `No path information available for ${item.Name || 'this item'}`;
      console.log('[Jellyfin Extension] No path available, using fallback');
    }
    
    // Clean up the title to remove 'Delete' and 'Identify'
    let rawTitle = (item.Name || item.OriginalTitle || 'Unknown Title').replace(/Delete|Identify/gi, '').trim();
    // Improved regex: split at first ' • ' or at first size/resolution/language/SDR/HDR
    let mediaTitle = rawTitle;
    let extraAttrs = '';
    // Try to split at first ' • '
    const dotSplit = rawTitle.split(/\s*•\s*/);
    if (dotSplit.length > 1) {
      mediaTitle = dotSplit[0].trim();
      extraAttrs = dotSplit.slice(1).join(' • ').trim();
    } else {
      // Fallback: split at first size/resolution/language/SDR/HDR
      const attrMatch = rawTitle.match(/^(.+?)(\d+\.\d+\s*(MB|GB|KB)|\d{3,4}×\d{3,4}|SDR|HDR|English|Japanese|Chinese|French|German|Spanish)/i);
      if (attrMatch) {
        mediaTitle = attrMatch[1].trim();
        extraAttrs = rawTitle.substring(mediaTitle.length).trim();
      }
    }
    const result = {
      title: mediaTitle,
      extraAttrs: extraAttrs,
      filename: filename,
      path: path
    };
    console.log('[Jellyfin Extension] Final item details:', result);
    return result;
    
  } catch (error) {
    console.error('[Jellyfin Extension] Error getting item details:', error);
    
    // Only use card content for title as a last resort, never for filename/path
    let fallbackTitle = 'Unknown Title';
    try {
      const cardElement = document.querySelector(`[data-id="${itemId}"]`);
      if (cardElement) {
        // Try to find the main title element only
        const titleElement = cardElement.querySelector('.cardText-first, .cardTitle, .itemName, h3, .primary');
        if (titleElement) {
          fallbackTitle = titleElement.textContent.trim();
          // Remove any attribute, button, or extra info
          fallbackTitle = fallbackTitle.replace(/(\d+\.\d+\s*(MB|GB|KB)|\d{3,4}×\d{3,4}|SDR|HDR|Delete|Identify|•|\s*\u2022\s*|\n.*)/g, '').trim();
        }
      }
    } catch (titleError) {
      console.error('[Jellyfin Extension] Failed to extract fallback title:', titleError);
    }
    // Never use card content for filename or path
    return {
      title: fallbackTitle,
      filename: 'Unable to retrieve filename',
      path: 'Unable to retrieve file path'
    };
  }
}

// Helper function to extract base URL
function extractBaseUrl() {
  try {
    if (window.ApiClient && window.ApiClient.serverAddress) {
      return window.ApiClient.serverAddress();
    }
    
    const currentUrl = window.location.href;
    const match = currentUrl.match(/^(https?:\/\/[^\/]+)/);
    return match ? match[1] : null;
  } catch (error) {
    console.error('[Jellyfin Extension] Error extracting baseUrl:', error);
    return null;
  }
}

// Helper function to extract access token
function extractAccessToken() {
  try {
    const token = localStorage.getItem('jellyfin_credentials');
    if (token) {
      const credentials = JSON.parse(token);
      return credentials.AccessToken;
    }
    
    // Alternative storage locations
    const altToken = localStorage.getItem('AccessToken') || 
                    sessionStorage.getItem('AccessToken') ||
                    localStorage.getItem('authToken');
    
    return altToken;
  } catch (error) {
    console.error('[Jellyfin Extension] Error extracting token:', error);
    return null;
  }
}

// Trigger Jellyfin's native identify dialog
function triggerIdentifyDialog(itemId) {
  console.log('[Jellyfin Extension] Triggering identify dialog for item:', itemId);
  
  try {
    // Method 1: Look for the card's more button and simulate click
    const cardElement = document.querySelector(`[data-id="${itemId}"]`);
    if (cardElement) {
      console.log('[Jellyfin Extension] Found card element:', cardElement);
      
      // Try different selectors for the more button
      const moreButtonSelectors = [
        '.btnCardMoreOptions',
        '.cardMoreButton',
        '.btnCardMore',
        '.card-more-button',
        '[data-action="menu"]',
        '.material-icons[title="More"]',
        '.md-icon-button[title="More"]',
        'button[title="More"]',
        '.more-vert',
        '.mdi-dots-vertical'
      ];
      
      let moreButton = null;
      for (const selector of moreButtonSelectors) {
        moreButton = cardElement.querySelector(selector);
        if (moreButton) {
          console.log('[Jellyfin Extension] Found more button with selector:', selector, moreButton);
          break;
        }
      }
      
      if (moreButton) {
        // Create a custom event to trigger the menu
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        
        moreButton.dispatchEvent(clickEvent);
        console.log('[Jellyfin Extension] Clicked more button');
        
        // Wait for menu to appear and look for identify option
        setTimeout(() => {
          const identifySelectors = [
            '[data-action="identify"]',
            '.menuItem[data-action="identify"]',
            '.listItem[data-action="identify"]',
            '.contextMenuItem[data-action="identify"]',
            '.menu-item[data-action="identify"]',
            '.identifyItem',
            '.btnIdentify'
          ];
          
          let identifyOption = null;
          for (const selector of identifySelectors) {
            identifyOption = document.querySelector(selector);
            if (identifyOption) {
              console.log('[Jellyfin Extension] Found identify option with selector:', selector, identifyOption);
              break;
            }
          }
          
          if (!identifyOption) {
            // Try to find by text content
            const allMenuItems = document.querySelectorAll('.menuItem, .listItem, .contextMenuItem, .menu-item, [role="menuitem"]');
            for (const item of allMenuItems) {
              const text = item.textContent?.toLowerCase() || '';
              if (text.includes('identify') || text.includes('edit metadata')) {
                identifyOption = item;
                console.log('[Jellyfin Extension] Found identify option by text:', item);
                break;
              }
            }
          }
          
          if (identifyOption) {
            const identifyClickEvent = new MouseEvent('click', {
              bubbles: true,
              cancelable: true,
              view: window
            });
            identifyOption.dispatchEvent(identifyClickEvent);
            console.log('[Jellyfin Extension] Clicked identify option');
          } else {
            console.log('[Jellyfin Extension] Identify option not found in menu');
            showFallbackInstructions('identify');
          }
        }, 300);
        return;
      }
    }
    
    // Method 2: Try to use Jellyfin's router to navigate to identify page
    if (window.Emby && window.Emby.Page) {
      const identifyUrl = `#!/itemidentifier.html?id=${itemId}`;
      console.log('[Jellyfin Extension] Trying to navigate to:', identifyUrl);
      window.Emby.Page.show(identifyUrl);
      return;
    }
    
    // Method 3: Try direct URL navigation
    const currentUrl = window.location.href;
    const baseUrl = currentUrl.split('/web/')[0];
    const identifyUrl = `${baseUrl}/web/index.html#!/itemidentifier.html?id=${itemId}`;
    console.log('[Jellyfin Extension] Navigating to identify URL:', identifyUrl);
    window.location.href = identifyUrl;
    return;
    
  } catch (error) {
    console.error('[Jellyfin Extension] Error in triggerIdentifyDialog:', error);
    showFallbackInstructions('identify');
  }
}

// Debug helper to inspect card structure
function debugCardStructure(itemId) {
  const cardElement = document.querySelector(`[data-id="${itemId}"]`);
  if (cardElement) {
    console.log('[Jellyfin Extension] Card HTML structure:', cardElement.outerHTML);
    console.log('[Jellyfin Extension] Card children:', Array.from(cardElement.children));
    
    // Look for all buttons in the card
    const buttons = cardElement.querySelectorAll('button, .btn, [role="button"]');
    console.log('[Jellyfin Extension] Found buttons in card:', buttons);
    
    buttons.forEach((btn, i) => {
      console.log(`[Jellyfin Extension] Button ${i}:`, {
        element: btn,
        classes: btn.className,
        title: btn.title,
        textContent: btn.textContent,
        dataset: btn.dataset
      });
    });
  }
}

// Show fallback instructions
function showFallbackInstructions(action) {
  const actionText = action === 'delete' ? 'delete this item' : 'identify this item';
  const instructions = `To ${actionText}:\n\n` +
    `1. Look for the three-dot menu button (⋮) on the movie card\n` +
    `2. Click it to open the context menu\n` +
    `3. Select "${action === 'delete' ? 'Delete' : 'Identify'}" from the menu\n\n` +
    `Alternatively, right-click on the movie card and select the option from the context menu.`;
  
  alert(instructions);
}

// Export to global scope for browser use
window.JellyfinExtension = window.JellyfinExtension || {};
window.JellyfinExtension.cardEnhancer = { 
  findMovieCards, 
  formatFileSize, 
  buildAttributesList, 
  addAttributesToCard, 
  addActionButtonsToCard,
  triggerDeleteDialog,
  triggerIdentifyDialog,
  triggerNativeDeleteProcess,
  debugCardStructure,
  getItemDetailsForDialog,
  executeDelete,
  triggerNativeDeleteWithoutDialog,
  fallbackDelete,
  extractBaseUrl,
  extractAccessToken
};

// ...more logic to be added via TDD
